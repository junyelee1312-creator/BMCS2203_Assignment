import streamlit as st
import requests
import pandas as pd
import time

# =====================================================
# 聊天历史
# =====================================================
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []
if 'last_response_time' not in st.session_state:
    st.session_state.last_response_time = 0.0
if 'dataset_row_count' not in st.session_state:
    st.session_state.dataset_row_count = 0

# =====================================================
# 读取你的 CSV dataset 并转换成知识库文本
# =====================================================
def load_csv_dataset(path="GYM.csv"):
    try:
        df = pd.read_csv(path)
    except:
        return "Error: GYM.csv file not found. Please ensure the file is in the same directory."
    st.session_state.dataset_row_count = len(df)
    kb_text = "The following is a knowledge base on fitness and healthy meals (from the dataset you provided):\n\n"

    for idx, row in df.iterrows():
        # 使用 .get 防止缺少列名报错
        kb_text += (
            f"sample {idx+1}：\n"
            f"- gender: {row.get('Gender', '')}\n"
            f"- goal: {row.get('Goal', '')}\n"
            f"- BMI Classification: {row.get('BMI Category', '')}\n"
            f"- Training Plan: {row.get('Exercise Schedule', '')}\n"
            f"- Fitness meal recommendations: {row.get('Meal Plan', '')}\n\n"
        )
    return kb_text

DATASET = load_csv_dataset()


# =====================================================
# 调用 Ollama
# =====================================================
def ask_ollama(prompt, model="llama3.1"):
    url = "http://localhost:11434/api/generate"
    start_time = time.time()
    payload = {"model": model, "prompt": prompt, "stream": False}
    try:
        response = requests.post(url, json=payload)
        if response.status_code == 200:
            end_time = time.time()
            st.session_state.last_response_time = end_time - start_time
            return response.json().get("response", "")
        else:
            return "Error: Ollama service exception"
    except:
        return "Error: Unable to connect to Ollama. Please check if it is running in the background."




# =====================================================
# 限制只回答健身领域
# =====================================================
def is_in_domain(msg):
    msg = msg.lower()
    keywords = [
        "健身", "健身房", "gym", "workout", "exercise", "fitness", "训练", "锻炼",
        "增肌", "bulk", "bulking", "gain muscle", "mass gain", 
        "减脂", "cut", "cutting", "fat loss", "lean",
        "健身餐", "营养", "营养素", "蛋白质", "碳水", "脂肪", "热量", "卡路里",
        "高蛋白", "低脂", "低卡", "饮食", "餐单", "meal", "diet", "nutrition",
        "protein", "carbs", "fat", "meal plan", "healthy meal",
        "深蹲", "卧推", "硬拉", "squat", "bench press", "deadlift",
        "chest", "back", "leg", "shoulder", "arm", "胸", "背", "肩", "腿",
        "训练计划", "program", "routine", "bmi", "体脂"
    ]
    return any(k in msg for k in keywords)

def normal_chat_with_history(msg):
    history = ""
    for h in st.session_state.chat_history:
        role = "用户" if h["role"] == "user" else "助手"
        history += f"{role}: {h['message']}\n"

    prompt = f"""
You are a friendly assistant; please continue the conversation based on the following chat history.
If the context is incomplete, you can ask the user for more information.

Chat history：
{history}

User asked：
{msg}

Please answer coherently.：
"""
    return ask_ollama(prompt)


# =====================================================
# 核心生成回答（RAG）
# =====================================================
def process_message(msg):
    if not is_in_domain(msg):
        return normal_chat_with_history(msg)

    history = ""
    for h in st.session_state.chat_history:
        role = "User" if h["role"] == "user" else "assistant"
        history += f"{role}: {h['message']}\n"

    prompt = f"""
You are a professional fitness consultant, and your answers must be based on the content provided in the dataset (CSV).

If there is no relevant information in the dataset, please answer: "No relevant information in the dataset".

Below is the dataset：
---
{DATASET}
---

Chat hixtory：
{history}

User question：
{msg}

Please provide a coherent answer based on the dataset and historical conversations.：
"""
    return ask_ollama(prompt)

# ================== 动态主题设置 (新增) ===================
def hex_to_rgba(hex_code, alpha=1.0):
    """Convert Hex colors to RGBA format for generating shadows."""
    hex_code = hex_code.lstrip('#')
    return tuple(int(hex_code[i:i+2], 16) for i in (0, 2, 4)) + (alpha,)

with st.sidebar:
    st.markdown("### 🎨 Interface Theme Settings")
    st.markdown("Custom background color")
    
    default_c1, default_c2, default_c3 = "#e9fffd", "#c8fff7", "#b3fff4"
    
    c1 = st.color_picker("Top color", default_c1)
    c2 = st.color_picker("Middle color", default_c2)
    c3 = st.color_picker("bottom color", default_c3)

    r, g, b, _ = hex_to_rgba(c2)
    bubble_shadow = f"rgba({r}, {g}, {b}, 0.45)"
    card_glow = f"rgba({r}, {g}, {b}, 0.4)"

    st.divider() 
    st.markdown("### 📊 System status")
    
    st.metric(label="Total number of samples in the dataset", 
              value=f"{st.session_state.dataset_row_count} sample")
    
    st.metric(label="Last thought time", 
              value=f"{st.session_state.last_response_time:.2f} Second")

st.markdown(f"""
<style>
    html, body, [class*="css"] {{font-family: 'SF Pro Display', -apple-system, sans-serif !important;}}
    

    .stApp {{
        background: linear-gradient(135deg, {c1} 0%, {c2} 50%, {c3} 100%);
        background-attachment: fixed;
        transition: background 0.5s ease; 
    }}

    section[data-testid="stSidebar"] {{
        background: linear-gradient(180deg, {c1}, {c3});
        border-right: 1px solid rgba(255, 255, 255, 0.5);
        box-shadow: none; 
    }}

    .main-card {{
        max-width: 960px;
        margin: 20px auto;
        background: rgba(255, 255, 255, 0.92);
        backdrop-filter: blur(28px);
        -webkit-backdrop-filter: blur(28px);
        border-radius: 36px;
        box-shadow: 0 30px 80px {card_glow};
        padding: 1px 35px;
        min-height: calc(100vh - 700px);
        border: 1.5px solid rgba(255,255,255,0.3);
    }}
    
    .title {{
        text-align: center;
        font-size: 54px;
        font-weight: 900;
        background: linear-gradient(90deg, #5ff7e6, {c2}, {c3});
        -webkit-background-clip: text;
        background-clip: text;
        -webkit-text-fill-color: transparent;
        margin: 0 0 10px 0;
    }}
    
    .subtitle {{
        text-align: center;
        color: #777;
        font-size: 19px;
        margin-bottom: 50px;
    }}

    .user-bubble {{
        background: linear-gradient(135deg, {c2}, {c1}); 
        color: #00332f !important;
        padding: 18px 26px;
        border-radius: 28px 28px 8px 28px;
        max-width: 78%;
        margin-left: auto;
        margin-bottom: 28px;
        box-shadow: 0 12px 35px {bubble_shadow};
        font-size: 17px;
        line-height: 1.65;
    }}

    .ai-bubble {{
        background: rgba(248,249,252,0.95);
        color: #2d3436 !important;
        padding: 18px 26px;
        border-radius: 28px 28px 28px 8px;
        max-width: 78%;
        margin-right: auto;
        margin-bottom: 28px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.12);
        font-size: 17px;
        line-height: 1.65;
        border: 1px solid rgba(0,0,0,0.05);
    }}
</style>

<script>
    const currentTheme = {{
        c1: "{c1}",
        c2: "{c2}",
        c3: "{c3}"
    }};

    localStorage.setItem("gym_app_theme", JSON.stringify(currentTheme));
</script>
""", unsafe_allow_html=True)
# ==================== 主界面 ====================
st.markdown('''<div class="main-card">
                <h1 class="title">🏋️‍♂️ Fitness Pro Coach</h1>
                <p class="subtitle">Your personal AI fitness and diet consultant · Based on a dedicated dataset</p>
                ''', unsafe_allow_html=True)

# 显示聊天记录
for chat in st.session_state.chat_history:
    if chat["role"] == "user":
        st.markdown(f'<div class="user-bubble">💪 {chat["message"]}</div>', unsafe_allow_html=True)
    else:
        st.markdown(f'<div class="ai-bubble">🤖 {chat["message"]}</div>', unsafe_allow_html=True)

st.markdown('</div>', unsafe_allow_html=True)
st.markdown("<script>parent.window.scrollTo(0, document.body.scrollHeight);</script>", unsafe_allow_html=True)

# ==================== 底部输入区 ===================
st.markdown('<div style="height: 10px"></div>', unsafe_allow_html=True) # 占位符，防遮挡

with st.container():
    with st.form(key="chat_form", clear_on_submit=True):
        user_text = st.text_input(
            "Enter your fitness question",
            placeholder="💬 Ask me about training plans, diet, and exercise instructions...",
            label_visibility="collapsed",
            key="msg_input"
        )
        
        col1, col2 = st.columns([3, 1])
        with col1:
            send = st.form_submit_button("🚀 Send", use_container_width=True)
        with col2:
            clear = st.form_submit_button("🗑️ Empty chat", use_container_width=True)

# ==================== 提交逻辑 (已修复) ===================
if clear:
    st.session_state.chat_history = []
    st.rerun()

if send and user_text.strip():
    msg = user_text.strip()
    st.session_state.chat_history.append({"role": "user", "message": msg})
    with st.spinner("AI Thinking..."):
        reply = process_message(msg)
    
    st.session_state.chat_history.append({"role": "assistant", "message": reply})
    st.rerun()