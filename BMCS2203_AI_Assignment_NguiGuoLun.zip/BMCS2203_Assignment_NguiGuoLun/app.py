import streamlit as st
from chatbot_model import GymChatbot
import time

# =========================================================
# PAGE CONFIG
# =========================================================
st.set_page_config(
    page_title="GymBot - Your Fitness Assistant",
    page_icon="💪",
    layout="wide"
)

# =========================================================
# CUSTOM CSS (SMALLER CHATBOX)
# =========================================================
st.markdown("""
<style>
body {
    background: #ECF0F3;
}

/* Chat container */
.chat-message {
    padding: 0.6rem;
    margin-bottom: 8px;
    border-radius: 12px;
    max-width: 70%;
    box-shadow: 1px 2px 6px rgba(0,0,0,0.05);
    font-size: 0.9rem;
    line-height: 1.2rem;
}

/* User bubble */
.user-message {
    background: linear-gradient(to right, #e3f2fd, #bbdefb);
    margin-left: auto;
    border: 1px solid #90caf9;
}

/* Bot bubble */
.bot-message {
    background: white;
    border-left: 4px solid #ff6b6b;
}

/* Title Style */
.main-title {
    background: linear-gradient(to right, #ff6b6b, #ff8e53);
    padding: 0.8rem;
    color: white;
    border-radius: 10px;
    text-align: center;
    font-size: 1.5rem;
    margin-bottom: 15px;
    box-shadow: 1px 2px 8px rgba(0,0,0,0.1);
}

/* Sidebar */
.sidebar-title {
    color: #ff6b6b;
    font-weight: 700;
    font-size: 1.1rem;
}

.try-btn {
    background: #ff6b6b !important;
    color: white !important;
    border-radius: 6px !important;
}
</style>
""", unsafe_allow_html=True)

# =========================================================
# LOAD CHATBOT
# =========================================================
@st.cache_resource
def load_chatbot():
    return GymChatbot("data/GYM.csv")

if "chatbot" not in st.session_state:
    st.session_state.chatbot = load_chatbot()

# =========================================================
# SESSION STATE
# =========================================================
if "messages" not in st.session_state:
    st.session_state.messages = []

# =========================================================
# GYM RELATED FILTER
# =========================================================
def is_gym_related(text):
    gym_keywords = [
        "gym","fitness","workout","exercise","training","muscle","fat","burn",
        "diet","meal","nutrition","bmi","bench","squat","deadlift",
        "lose weight","gain weight","overweight","underweight"
    ]
    t = text.lower()
    return any(k in t for k in gym_keywords)

def handle_user_query(message):
    if not is_gym_related(message):
        return {
            "response": "⚠️ This question is **not related to gym, fitness, nutrition, or workouts**. It is outside my expertise.",
            "source": "system_filter",
            "confidence": 1.0,
            "intent": "not_gym_related"
        }
    return st.session_state.chatbot.get_response(message)

# =========================================================
# SIDEBAR
# =========================================================
with st.sidebar:
    st.markdown("<p class='sidebar-title'>💪 GymBot Menu</p>", unsafe_allow_html=True)
    st.markdown("---")

    # Quick Actions
    st.subheader("✨ Quick Actions")
    if st.button("🗑️ Clear Chat History"):
        st.session_state.messages = []
        st.rerun()

    st.markdown("---")
    st.subheader("💡 Try Asking")
    sample_questions = [
        "I want to gain muscle",
        "How can I burn fat?",
        "Suggest a meal plan",
        "Exercises for overweight people",
        "I am underweight, what should I eat?"
    ]
    for q in sample_questions:
        if st.button(q, key=q, use_container_width=True):
            st.session_state.messages.append({"role": "user", "content": q})
            result = handle_user_query(q)
            st.session_state.messages.append({
                "role": "assistant",
                "content": result["response"],
                "metadata": result
            })
            st.rerun()

# =========================================================
# MAIN TITLE
# =========================================================
st.markdown("<div class='main-title'>💪 GymBot — Your Personal Fitness Assistant</div>", unsafe_allow_html=True)
st.markdown("### *Ask me anything about workouts, muscle building, fat loss, or nutrition.*")

# =========================================================
# DISPLAY CHAT HISTORY
# =========================================================
for msg in st.session_state.messages:
    if msg["role"] == "user":
        st.markdown(
            f"<div class='chat-message user-message'><b>You:</b> {msg['content']}</div>",
            unsafe_allow_html=True
        )
    else:
        meta = msg.get("metadata", {})
        src = meta.get("source", "")
        emoji = "🤖"
        if src == "dataset": emoji = "📘"
        elif src == "llm_with_context": emoji = "🤖✨"
        elif src == "system_filter": emoji = "⚠️"

        st.markdown(
            f"<div class='chat-message bot-message'><b>{emoji} GymBot:</b> {msg['content']}</div>",
            unsafe_allow_html=True
        )

# =========================================================
# USER CHAT INPUT
# =========================================================
user_input = st.chat_input("Type your fitness question here...")

if user_input:
    st.session_state.messages.append({"role": "user", "content": user_input})
    with st.spinner("💭 Thinking..."):
        result = handle_user_query(user_input)
        st.session_state.messages.append({
            "role": "assistant",
            "content": result["response"],
            "metadata": result
        })
    st.rerun()
