import os
import time
import requests
import random
import warnings
from collections import Counter

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend
import matplotlib.pyplot as plt

warnings.filterwarnings("ignore")


class LLMGymClassifier:
    def __init__(
        self,
        csv_path="data/GYM.csv",
        ollama_url="http://localhost:11434",
        openrouter_url="https://openrouter.ai/api/v1/chat/completions",
        grok_api_key=None,
        grok_model="x-ai/grok-4.1-fast",
        request_timeout=30,
        max_retries=2,
    ):
        self.csv_path = csv_path
        self.ollama_url = ollama_url
        self.openrouter_url = openrouter_url
        self.grok_api_key = grok_api_key or os.getenv("OPENROUTER_API_KEY")
        self.grok_model = grok_model
        self.request_timeout = request_timeout
        self.max_retries = max_retries

        self.df = None
        self.classes = []
        self.test_data = []
        self.ground_truth = []

    # -------------------------
    # Logging helpers
    # -------------------------
    def info(self, *args):
        print("[INFO]", *args)

    def error(self, *args):
        print("[ERROR]", *args)

    # ==========================================================
    # LOAD DATASET
    # ==========================================================
    def load_data(self):
        self.info(f"Loading dataset from: {self.csv_path}")
        try:
            self.df = pd.read_csv(self.csv_path)
            self.classes = sorted(self.df["Goal"].unique().tolist())
            self.info(f"Loaded {len(self.df)} rows. Target classes: {self.classes}")
            return True
        except Exception as e:
            self.error("Failed to load dataset:", e)
            return False

    # ==========================================================
    # CHECK OLLAMA CONNECTION
    # ==========================================================
    def check_ollama_connection(self, model_list):
        ollama_models = [m for m in model_list if m != "grok"]
        if not ollama_models:
            return True
        try:
            r = requests.get(f"{self.ollama_url}/api/tags", timeout=5)
            if r.status_code != 200:
                self.error("Ollama server returned non-200:", r.status_code)
                return False
            available = [m["name"] for m in r.json().get("models", [])]
            missing = [m for m in ollama_models if m not in available]
            if missing:
                self.error("Missing Ollama models:", missing)
                return False
            self.info("All Ollama models available.")
            return True
        except Exception as e:
            self.error("Unable to reach Ollama server:", e)
            return False

    # ==========================================================
    # CREATE TEST QUESTIONS
    # ==========================================================
    def create_test_questions(self, num_questions=25, seed=42):
        random.seed(seed)
        np.random.seed(seed)
        self.test_data = []
        self.ground_truth = []

        if not self.classes:
            raise RuntimeError("Classes empty — load data first.")

        dominant = self.classes[0]
        minority = self.classes[1:]
        n_dom = int(num_questions * 0.7)
        n_min = num_questions - n_dom

        dom_df = self.df[self.df["Goal"] == dominant]
        dom_samples = dom_df.sample(n=n_dom, replace=True, random_state=seed)

        min_df = self.df[self.df["Goal"].isin(minority)]
        if min_df.empty and n_min > 0:
            min_samples = dom_df.sample(n=n_min, replace=True, random_state=seed + 1)
        else:
            min_samples = min_df.sample(n=n_min, replace=True, random_state=seed + 2)

        def build_prompt(row):
            return (
                f"I am a {row['Gender']} with {row['BMI Category']} BMI, "
                f"exercise: {row['Exercise Schedule']}, diet: {row['Meal Plan']}. "
                "What fitness goal should I focus on?"
            )

        for _, r in dom_samples.iterrows():
            self.test_data.append(build_prompt(r))
            self.ground_truth.append(dominant)

        for _, r in min_samples.iterrows():
            self.test_data.append(build_prompt(r))
            self.ground_truth.append(r["Goal"])

        self.info(f"Created {len(self.test_data)} test questions (dominant: {n_dom}, minority: {n_min})")

    # ==========================================================
    # QUERY OLLAMA
    # ==========================================================
    def query_ollama(self, model_name, prompt):
        try:
            r = requests.post(
                f"{self.ollama_url}/api/generate",
                json={"model": model_name, "prompt": prompt, "stream": False, "options": {"temperature": 0.1}},
                timeout=self.request_timeout,
            )
            if r.status_code == 200:
                return r.json().get("response", "")
            self.error(f"Ollama failed for {model_name}:", r.status_code, r.text[:500])
            return None
        except Exception as e:
            self.error(f"Ollama exception for {model_name}:", e)
            return None

    # ==========================================================
    # QUERY GROK
    # ==========================================================
    def query_grok(self, prompt):
        if not self.grok_api_key:
            self.error("Grok API key not configured. Set OPENROUTER_API_KEY env var or pass grok_api_key.")
            return None

        headers = {
            "Authorization": f"Bearer {self.grok_api_key}",
            "Content-Type": "application/json"
        }

        payload = {
            "model": self.grok_model,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 128,
            "temperature": 0.1
        }

        last_err = None
        for attempt in range(1, self.max_retries + 2):
            try:
                r = requests.post(self.openrouter_url, headers=headers, json=payload, timeout=self.request_timeout)
                if r.status_code == 200:
                    data = r.json()
                    if "choices" in data and len(data["choices"]) > 0:
                        content = data["choices"][0].get("message", {}).get("content", "")
                        return content
                    else:
                        self.error("Grok returned 200 but no choices field. Raw:", data)
                        return None
                else:
                    last_err = f"Status {r.status_code}: {r.text[:400]}"
                    if r.status_code in (401, 403, 404):
                        self.error("Auth/NotFound error contacting OpenRouter:", last_err)
                        return None
                    self.info(f"Grok API returned {r.status_code}. Attempt {attempt}/{self.max_retries+1}. Retrying...")
                    time.sleep(1 + attempt * 0.5)
            except requests.RequestException as e:
                last_err = str(e)
                self.info(f"Grok request exception: {e}. Attempt {attempt}/{self.max_retries+1}. Retrying...")
                time.sleep(1 + attempt * 0.5)

        self.error("Grok requests failed after retries. Last error:", last_err)
        return None

    # ==========================================================
    # QUERY MODEL DISPATCH
    # ==========================================================
    def query_model(self, model_name, prompt):
        if model_name == "grok":
            return self.query_grok(prompt)
        else:
            return self.query_ollama(model_name, prompt)

    # ==========================================================
    # PARSE RAW RESPONSE TO CLASS
    # ==========================================================
    def parse_prediction_from_text(self, text):
        if not text or not text.strip():
            return None
        text_low = text.lower()
        for cls in self.classes:
            if cls.lower() in text_low:
                return cls
        text_tokens = set([w.strip(".,!?:;()[]") for w in text_low.split() if len(w) > 1])
        best = None
        best_score = 0
        for cls in self.classes:
            cls_tokens = set([w.strip(".,!?:;()[]") for w in cls.lower().split() if len(w) > 1])
            overlap = len(text_tokens & cls_tokens)
            score = overlap / (len(cls_tokens) + 1e-9) if cls_tokens else 0
            if score > best_score:
                best_score = score
                best = cls
        if best_score >= 0.2:
            return best
        return None

    # ==========================================================
    # TEST SINGLE MODEL
    # ==========================================================
    def test_single_model(self, model_name, show_raw=False):
        predictions = []
        response_times = []
        dominant_class = self.classes[0]

        self.info(f"Starting test for {model_name}...")
        
        for i, user_msg in enumerate(self.test_data):
            prompt = (
                "You are a fitness assistant. Choose ONE goal from the following EXACT list: "
                f"{', '.join(self.classes)}.\n"
                "Respond with the exact goal name only (no explanation).\n\n"
                f"{user_msg}"
            )
            start = time.time()
            raw = self.query_model(model_name, prompt)
            elapsed = time.time() - start
            response_times.append(elapsed)

            if show_raw:
                print(f"\n--- raw response ({model_name}) q#{i+1} ---\n{raw}\n----------------------")

            predicted = self.parse_prediction_from_text(raw)
            if predicted is None:
                predicted = dominant_class
            predictions.append(predicted)
            
            # Progress indicator
            if (i + 1) % 5 == 0:
                self.info(f"  {model_name}: Completed {i+1}/{len(self.test_data)} questions")

        self.info(f"Completed testing {model_name}")
        return predictions, response_times

    # ==========================================================
    # CALCULATE METRICS
    # ==========================================================
    def calculate_metrics(self, predictions):
        correct = sum(p == t for p, t in zip(predictions, self.ground_truth))
        accuracy = correct / len(self.ground_truth) if self.ground_truth else 0.0
        counts = Counter(self.ground_truth)
        total = len(self.ground_truth) if self.ground_truth else 1

        precision_avg = recall_avg = f1_avg = 0.0
        for cls in self.classes:
            tp = sum(p == cls and t == cls for p, t in zip(predictions, self.ground_truth))
            fp = sum(p == cls and t != cls for p, t in zip(predictions, self.ground_truth))
            fn = sum(p != cls and t == cls for p, t in zip(predictions, self.ground_truth))
            precision = tp / (tp + fp) if (tp + fp) else 0.0
            recall = tp / (tp + fn) if (tp + fn) else 0.0
            f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0.0
            weight = counts[cls] / total
            precision_avg += precision * weight
            recall_avg += recall * weight
            f1_avg += f1 * weight

        return {"accuracy": accuracy, "precision": precision_avg, "recall": recall_avg, "f1_score": f1_avg}

    # ==========================================================
    # PLOTTING / VISUALIZATIONS
    # ==========================================================
    def actual_vs_predicted_scatter(self, results, model_name):
        if model_name not in results:
            self.error(f"Model {model_name} not found in results")
            return

        try:
            predictions = results[model_name]["predictions"]
            numeric_mapping = {goal: idx for idx, goal in enumerate(self.classes)}
            actual_numeric = [numeric_mapping[gt] for gt in self.ground_truth]
            predicted_numeric = [numeric_mapping[pred] for pred in predictions]
            jitter = 0.15
            actual_jittered = [x + random.uniform(-jitter, jitter) for x in actual_numeric]
            predicted_jittered = [y + random.uniform(-jitter, jitter) for y in predicted_numeric]

            plt.figure(figsize=(10, 8))
            max_val = len(self.classes) - 1
            min_val = 0
            ideal_line = np.linspace(min_val - 0.5, max_val + 0.5, 100)
            plt.plot(ideal_line, ideal_line, 'r--', linewidth=2, label='Ideal Line', alpha=0.7)
            plt.scatter(actual_jittered, predicted_jittered,
                        alpha=0.6, s=100, color='blue', edgecolors='darkblue', linewidth=0.5)
            plt.xlabel(f'Actual {model_name}', fontsize=12, fontweight='bold')
            plt.ylabel(f'Predicted {model_name}', fontsize=12, fontweight='bold')
            plt.title(f'Actual vs Predicted {model_name} (Scatter Plot)', fontsize=14, fontweight='bold')
            plt.xlim(min_val - 0.5, max_val + 0.5)
            plt.ylim(min_val - 0.5, max_val + 0.5)
            tick_positions = list(range(len(self.classes)))
            plt.xticks(tick_positions, self.classes, rotation=45, ha='right')
            plt.yticks(tick_positions, self.classes)
            plt.grid(True, linestyle='--', alpha=0.3)
            plt.legend(loc='upper left', fontsize=10)
            plt.tight_layout()
            
            # Sanitize model name for filename
            safe_model_name = model_name.replace(":", "_").replace("/", "_")
            filename = f"scatter_plot_{safe_model_name}.png"
            plt.savefig(filename, dpi=300, bbox_inches='tight')
            plt.close()  # Close the figure to free memory
            self.info(f"✓ Saved scatter plot: {filename}")
        except Exception as e:
            self.error(f"Failed to create scatter plot for {model_name}:", e)

    def learning_curve(self, results, model_name):
        if model_name not in results:
            self.error(f"Model {model_name} not found in results")
            return

        try:
            preds = results[model_name]["predictions"]
            truths = self.ground_truth
            acc_list = []
            x = []

            for i in range(2, len(preds) + 1):
                sub_preds = preds[:i]
                sub_truths = truths[:i]
                correct = sum(p == t for p, t in zip(sub_preds, sub_truths))
                acc_list.append(correct / len(sub_truths))
                x.append(i)

            plt.figure(figsize=(10, 6))
            plt.plot(x, acc_list, marker="o", linewidth=2, color='green')
            plt.title(f"Learning Curve — {model_name}", fontsize=14, fontweight='bold')
            plt.xlabel("Number of Test Questions", fontsize=12)
            plt.ylabel("Accuracy", fontsize=12)
            plt.grid(True, linestyle="--", alpha=0.5)
            plt.tight_layout()
            
            # Sanitize model name for filename
            safe_model_name = model_name.replace(":", "_").replace("/", "_")
            filename = f"learning_curve_{safe_model_name}.png"
            plt.savefig(filename, dpi=300)
            plt.close()  # Close the figure to free memory
            self.info(f"✓ Saved learning curve: {filename}")
        except Exception as e:
            self.error(f"Failed to create learning curve for {model_name}:", e)

    def bar_plot_model_comparison(self, results):
        try:
            models = list(results.keys())
            accuracy_scores = [results[m]["metrics"]["accuracy"] for m in models]
            precision_scores = [results[m]["metrics"]["precision"] for m in models]
            f1_scores = [results[m]["metrics"]["f1_score"] for m in models]

            x = np.arange(len(models))
            width = 0.25

            fig, ax = plt.subplots(figsize=(12, 7))
            bars1 = ax.bar(x - width, accuracy_scores, width, label='Accuracy', color='#5cb85c', edgecolor='black', linewidth=0.7)
            bars2 = ax.bar(x, precision_scores, width, label='Precision', color='#5bc0de', edgecolor='black', linewidth=0.7)
            bars3 = ax.bar(x + width, f1_scores, width, label='F1-Score', color='#f0ad4e', edgecolor='black', linewidth=0.7)

            for bars in (bars1, bars2, bars3):
                for bar in bars:
                    height = bar.get_height()
                    ax.text(bar.get_x() + bar.get_width()/2., height + 0.02, f'{height*100:.1f}%', ha='center', va='bottom', fontsize=10, fontweight='bold')

            ax.set_ylabel('Score (0-1 scale)', fontsize=12, fontweight='bold')
            ax.set_title('Model Comparison — Accuracy vs Precision vs F1 Score', fontsize=14, fontweight='bold', pad=20)
            ax.set_xticks(x)
            ax.set_xticklabels(models, fontsize=11)
            ax.set_ylim(0, 1.1)
            ax.set_yticks(np.arange(0, 1.2, 0.2))
            ax.legend(loc='upper right', fontsize=11, framealpha=0.9)
            ax.grid(axis='y', linestyle='--', alpha=0.3)
            plt.tight_layout()
            filename = "bar_plot_model_comparison.png"
            plt.savefig(filename, dpi=300, bbox_inches='tight')
            plt.close()  # Close the figure to free memory
            self.info(f"✓ Saved bar plot: {filename}")
        except Exception as e:
            self.error(f"Failed to create bar plot comparison:", e)

    # ==========================================================
    # RUN MULTI-MODEL TEST WITH FULL PLOTS
    # ==========================================================
    def run_multi_model_test(self, model_list, num_questions=25, show_raw=False):
        self.info(f"Starting multi-model test with {len(model_list)} models")
        
        # Check connections (but don't fail if Ollama unavailable)
        ollama_available = self.check_ollama_connection(model_list)
        if not ollama_available:
            self.info("Ollama not available - will only test Grok models")
        
        # Load data
        if not self.load_data():
            self.error("Failed to load data. Exiting.")
            return None
        
        # Create test questions
        self.create_test_questions(num_questions)
        
        all_results = {}
        failed_models = []

        # Test each model
        for model in model_list:
            self.info(f"\n{'='*60}")
            self.info(f"Testing model: {model}")
            self.info(f"{'='*60}")
            
            try:
                preds, times = self.test_single_model(model, show_raw=show_raw)
                metrics = self.calculate_metrics(preds)
                all_results[model] = {
                    "metrics": metrics, 
                    "response_times": times, 
                    "predictions": preds
                }
                self.info(f"✓ Result for {model}: accuracy={metrics['accuracy']:.4f}")
            except Exception as e:
                self.error(f"✗ Failed to test {model}: {e}")
                failed_models.append(model)
                continue

        if not all_results:
            self.error("No models were successfully tested. Exiting.")
            return None

        # Print results table
        print("\n" + "=" * 80)
        print("EVALUATION METRICS SUMMARY")
        print("=" * 80)
        print(f"{'Model':20s} {'Accuracy':10s} {'Precision':10s} {'Recall':10s} {'F1':10s} {'Avg Time':10s}")
        print("-" * 80)
        for model, res in all_results.items():
            met = res["metrics"]
            avg_t = np.mean(res["response_times"]) if res["response_times"] else 0.0
            print(f"{model:20s} {met['accuracy']:<10.4f} {met['precision']:<10.4f} {met['recall']:<10.4f} {met['f1_score']:<10.4f} {avg_t:<10.3f}")
        print("=" * 80)

        if failed_models:
            print(f"\n⚠ Failed models: {', '.join(failed_models)}")

        # Generate visualizations
        self.info("\n" + "="*60)
        self.info("Generating visualizations...")
        self.info("="*60)
        
        # Bar plot comparison (for all successfully tested models)
        self.bar_plot_model_comparison(all_results)
        
        # Individual model plots
        for model in all_results.keys():
            self.info(f"\nCreating plots for {model}...")
            self.actual_vs_predicted_scatter(all_results, model)
            self.learning_curve(all_results, model)

        self.info("\n" + "="*60)
        self.info("✓ All tests and visualizations complete!")
        self.info(f"✓ Generated {len(all_results) * 2 + 1} plot files")
        self.info("="*60)
        
        return all_results


# ==========================================================
# MAIN
# ==========================================================
def main():
    # Get API key from environment or use provided key
    grok_key = os.getenv("OPENROUTER_API_KEY") or "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"

    tester = LLMGymClassifier(
        csv_path="data/GYM.csv",
        grok_api_key=grok_key,
        grok_model="x-ai/grok-4.1-fast",
        openrouter_url="https://openrouter.ai/api/v1/chat/completions",
        ollama_url="http://localhost:11434",
        request_timeout=30,
        max_retries=2
    )

    # Test all models
    model_list = ["grok", "llama3.1:8b", "llama2:latest"]
    results = tester.run_multi_model_test(model_list, num_questions=25, show_raw=False)
    
    if results:
        print("\n✓ Test completed successfully!")
        print(f"✓ Check your directory for PNG files:")
        for model in results.keys():
            safe_name = model.replace(":", "_").replace("/", "_")
            print(f"  - scatter_plot_{safe_name}.png")
            print(f"  - learning_curve_{safe_name}.png")
        print(f"  - bar_plot_model_comparison.png")
    else:
        print("\n✗ Test failed - no results generated")


if __name__ == "__main__":
    main()