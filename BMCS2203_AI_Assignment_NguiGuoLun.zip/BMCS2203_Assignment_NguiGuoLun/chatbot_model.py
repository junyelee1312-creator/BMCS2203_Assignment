import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import ollama

class GymChatbot:
    def __init__(self, dataset_path='data/GYM.csv', model_name='llama2:latest'):
        """Initialize the gym chatbot with dataset"""
        self.dataset_path = dataset_path
        self.df = None
        self.vectorizer = TfidfVectorizer()
        self.exercise_vectors = None
        self.load_dataset()
        
    def load_dataset(self):
        """Load and preprocess the gym dataset"""
        try:
            self.df = pd.read_csv(self.dataset_path)
            # Create a combined text column for similarity search
            self.df['combined'] = (
                self.df['Goal'].str.lower() + ' ' +
                self.df['BMI Category'].str.lower() + ' ' +
                self.df['Exercise Schedule'].str.lower() + ' ' +
                self.df['Meal Plan'].str.lower()
            )
            # Fit TF-IDF on combined text
            self.exercise_vectors = self.vectorizer.fit_transform(self.df['combined'])
            print(f"✅ Dataset loaded: {len(self.df)} entries")
        except FileNotFoundError:
            print(f"⚠️ Dataset not found at {self.dataset_path}")
            self.df = pd.DataFrame(columns=['Gender', 'Goal', 'BMI Category', 'Exercise Schedule', 'Meal Plan'])
    
    def find_best_match(self, user_query, threshold=0.3):
        """Find the most similar row in dataset using TF-IDF"""
        if self.df.empty:
            return None, 0.0
        
        query_vector = self.vectorizer.transform([user_query.lower()])
        similarities = cosine_similarity(query_vector, self.exercise_vectors)
        best_idx = np.argmax(similarities)
        best_score = similarities[0][best_idx]
        
        if best_score > threshold:
            return self.df.iloc[best_idx], best_score
        return None, best_score
    
    def get_ollama_response(self, user_query, context=""):
        """Fallback response from Ollama LLM"""
        try:
            system_prompt = """You are a friendly and knowledgeable gym assistant chatbot.
            Your role is to provide personalized advice about workouts, nutrition, and gym plans.
            Keep responses concise and encouraging."""
            
            if context:
                system_prompt += f"\n\nRelevant information: {context}"
            
            response = ollama.chat(
                model='llama2:latest',
                messages=[
                    {'role': 'system', 'content': system_prompt},
                    {'role': 'user', 'content': user_query}
                ]
            )
            
            return response['message']['content']
        except Exception as e:
            return f"⚠️ Error connecting to Ollama: {str(e)}"
    
    def get_response(self, user_query):
        """Get chatbot response"""
        match, score = self.find_best_match(user_query)
        
        if match is not None and score > 0.6:
            answer = (f"🏋️‍♂️ Exercise Plan: {match['Exercise Schedule']}\n"
                      f"🥗 Meal Plan: {match['Meal Plan']}")
            return {'response': answer, 'source': 'dataset', 'confidence': float(score), 'intent': match['Goal']}
        elif match is not None:
            context = (f"Exercise Plan: {match['Exercise Schedule']}\n"
                       f"Meal Plan: {match['Meal Plan']}")
            llm_response = self.get_ollama_response(user_query, context)
            return {'response': llm_response, 'source': 'llm_with_context', 'confidence': float(score), 'intent': match['Goal']}
        else:
            llm_response = self.get_ollama_response(user_query)
            return {'response': llm_response, 'source': 'llm', 'confidence': float(score), 'intent': 'general'}
