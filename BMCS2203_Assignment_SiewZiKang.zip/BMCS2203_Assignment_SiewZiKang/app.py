from flask import Flask, render_template, request, jsonify, session
import requests
import os
import pandas as pd
from dotenv import load_dotenv
import chromadb
from chromadb.utils import embedding_functions
import uuid
from datetime import datetime

load_dotenv()
API_KEY = os.getenv("OPENROUTER_API_KEY")
API_URL = "https://openrouter.ai/api/v1/chat/completions"

app = Flask(__name__)
app.secret_key = "your-secret-key-here"  
MAX_MEMORY = 10

chat_sessions = {}

# -------------------- Excel Dataset --------------------
EXCEL_FILE = "GYM.xlsx"
df = pd.read_excel(EXCEL_FILE)

client = chromadb.PersistentClient(path="./chroma_db")
ef = embedding_functions.DefaultEmbeddingFunction()

collection = client.get_or_create_collection(
    name="excel_data", 
    embedding_function=ef
)

if collection.count() == 0:
    for idx, row in df.iterrows():
        text = " | ".join([str(v) for v in row.values])
        collection.add(
            documents=[text], 
            metadatas=[{"row": idx}], 
            ids=[str(idx)]
        )
    print(f"✅ Loaded {len(df)} rows into ChromaDB")
else:
    print(f"ℹ️  ChromaDB already contains {collection.count()} documents")

# -------------------- Helper Functions --------------------
def create_new_chat():
    """创建新的聊天会话"""
    chat_id = str(uuid.uuid4())
    chat_sessions[chat_id] = {
        "title": "New Chat",
        "messages": [{
            "role": "system", 
            "content": """You are a helpful fitness and nutrition assistant. 

When providing schedules, timetables, workout plans, or meal plans:
- ALWAYS use proper Markdown table format
- Include ALL days requested (e.g., full week = 7 days)
- Be complete and detailed

IMPORTANT: Always complete your full response. Never stop mid-table."""
        }],
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    return chat_id

def get_chat_title(messages):
    """根据第一条用户消息生成标题"""
    for msg in messages:
        if msg["role"] == "user":
            content = msg["content"][:50] 
            return content + "..." if len(msg["content"]) > 50 else content
    return "New Chat"

# -------------------- Flask Routes --------------------
@app.route("/")
def index():
    return render_template("chat.html")

@app.route("/new_chat", methods=["POST"])
def new_chat():
    """创建新对话"""
    chat_id = create_new_chat()
    return jsonify({
        "status": "success",
        "chat_id": chat_id,
        "title": "New Chat"
    })

@app.route("/get_chats", methods=["GET"])
def get_chats():
    """获取所有对话列表"""
    chats = []
    for chat_id, data in chat_sessions.items():
        chats.append({
            "id": chat_id,
            "title": data["title"],
            "created_at": data["created_at"]
        })
    chats.sort(key=lambda x: x["created_at"], reverse=True)
    return jsonify(chats)

@app.route("/load_chat/<chat_id>", methods=["GET"])
def load_chat(chat_id):
    """加载指定对话的消息"""
    if chat_id not in chat_sessions:
        return jsonify({"error": "Chat not found"}), 404
    
    messages = chat_sessions[chat_id]["messages"]
    user_messages = [msg for msg in messages if msg["role"] != "system"]
    return jsonify({
        "messages": user_messages,
        "title": chat_sessions[chat_id]["title"]
    })

@app.route("/delete_chat/<chat_id>", methods=["POST"])
def delete_chat(chat_id):
    """删除指定对话"""
    if chat_id in chat_sessions:
        del chat_sessions[chat_id]
        return jsonify({"status": "success"})
    return jsonify({"error": "Chat not found"}), 404

@app.route("/chat", methods=["POST"])
def chat():
    """发送消息"""
    data = request.json
    chat_id = data.get("chat_id")
    user_input = data.get("message", "").strip()
    
    if not user_input:
        return jsonify({"error": "Empty message"}), 400
    
    if 'file' in request.files:
        file = request.files['file']
        chat_id = request.form.get("chat_id")
        user_input = request.form.get("message", "").strip()
        
        file_content = ""
        if file.filename.endswith(('.txt', '.csv')):
            file_content = file.read().decode('utf-8')
        elif file.filename.endswith(('.xlsx', '.xls')):
            df_upload = pd.read_excel(file)
            file_content = df_upload.to_string()
        
        full_message = f"[File: {file.filename}]\n{file_content}\n\nUser question: {user_input}"
    else:
        data = request.json
        chat_id = data.get("chat_id")
        full_message = data.get("message", "").strip()
        user_input = full_message
    
    if not user_input and not file_content:
        return jsonify({"error": "Empty message"}), 400
    
    if not chat_id or chat_id not in chat_sessions:
        chat_id = create_new_chat()
    
    chat_sessions[chat_id]["messages"].append({
        "role": "user",
        "content": full_message
    })

    if not chat_id or chat_id not in chat_sessions:
        chat_id = create_new_chat()
    
    chat_sessions[chat_id]["messages"].append({
        "role": "user",
        "content": user_input
    })
    
    if chat_sessions[chat_id]["title"] == "New Chat":
        chat_sessions[chat_id]["title"] = get_chat_title(chat_sessions[chat_id]["messages"])
    
    messages = chat_sessions[chat_id]["messages"][-MAX_MEMORY:]
    
    dataset_keywords = ["dataset", "数据", "excel", "表格", "资料", "计划", "健身", "饮食"]
    trigger_dataset = any(keyword.lower() in user_input.lower() for keyword in dataset_keywords)
    
    if trigger_dataset:
        results = collection.query(query_texts=[user_input], n_results=3)
        retrieved_docs = results['documents'][0] if results['documents'] else []
        
        if retrieved_docs:
            system_msg = "Here is relevant data from Excel for reference:\n" + "\n".join(retrieved_docs)
            messages_with_context = [{"role": "system", "content": system_msg}] + messages
        else:
            messages_with_context = messages
    else:
        messages_with_context = messages
    
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json",
    }
    
    api_data = {
        "model": "x-ai/grok-4.1-fast:free",
        "messages": messages_with_context,
        "temperature": 0.7,
        "max_tokens": 2000
    }
    
    try:
        resp = requests.post(API_URL, json=api_data, headers=headers)
        resp.raise_for_status()
        reply = resp.json()['choices'][0]['message']['content'].strip()
    except Exception as e:
        reply = f"Error: {str(e)}"
    
    chat_sessions[chat_id]["messages"].append({
        "role": "assistant",
        "content": reply
    })
    
    return jsonify({
        "status": "success",
        "chat_id": chat_id,
        "reply": reply,
        "title": chat_sessions[chat_id]["title"]
    })

if __name__ == "__main__":
    print("🚀 Running Smart ChatBot at http://127.0.0.1:5000")
    app.run(debug=True)